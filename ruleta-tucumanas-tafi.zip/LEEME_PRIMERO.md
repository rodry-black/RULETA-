# Ruleta de Premios · Tucumanas Tafi

## Qué hay en esta carpeta

- `schema.sql` — el SQL completo (ya lo corriste en Supabase, queda aquí de respaldo)
- `ruleta-app/` — la aplicación web, ya conectada a tu proyecto de Supabase

## Siguiente paso

Entra a la carpeta `ruleta-app/` y sigue las instrucciones de su `README.md`
para probarla en tu compu y luego publicarla (recomendado: Vercel, gratis).
