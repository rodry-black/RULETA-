-- ============================================================
-- RULETA DE PREMIOS - Promo Tucumanas Tafi (feria/evento)
-- Proyecto Supabase independiente del POS oficial
-- ============================================================

-- Extensión para generar códigos aleatorios seguros
create extension if not exists "pgcrypto";

-- ------------------------------------------------------------
-- Tabla: wheel_prizes
-- Cada premio configurable de la ruleta
-- ------------------------------------------------------------
create table wheel_prizes (
  id bigint generated always as identity primary key,
  name text not null,
  color text not null default '#D97757',       -- color del gajo en la ruleta
  quantity_total integer not null check (quantity_total >= 0),
  quantity_remaining integer not null check (quantity_remaining >= 0),
  weight numeric(6,3) not null default 0,       -- peso/probabilidad relativa (0-100 o proporcional)
  weight_is_manual boolean not null default false, -- true = el usuario lo sobrescribió a mano
  active boolean not null default true,         -- para ocultar un premio sin borrarlo
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  constraint remaining_lte_total check (quantity_remaining <= quantity_total)
);

comment on table wheel_prizes is 'Premios configurables de la ruleta, con cantidad y peso/probabilidad';
comment on column wheel_prizes.weight is 'Peso relativo usado para el sorteo ponderado. Si weight_is_manual=false se recalcula automáticamente proporcional a quantity_remaining';
comment on column wheel_prizes.weight_is_manual is 'Si el usuario editó el peso a mano, se congela y ya no se recalcula automáticamente al cambiar cantidades';

-- ------------------------------------------------------------
-- Tabla: wheel_codes
-- Cada código generado al girar la ruleta
-- ------------------------------------------------------------
create table wheel_codes (
  id bigint generated always as identity primary key,
  code text not null unique,                    -- formato TAFI-XXXXXX
  prize_id bigint not null references wheel_prizes(id),
  status text not null default 'pendiente'
    check (status in ('pendiente', 'canjeado', 'expirado')),
  spun_at timestamptz not null default now(),
  redeemed_at timestamptz,
  redeemed_by text,                              -- nombre/usuario de quien lo canjeó
  notes text,
  created_at timestamptz not null default now()
);

comment on table wheel_codes is 'Códigos de premio generados en cada giro, para validar y canjear después';

create index idx_wheel_codes_status on wheel_codes(status);
create index idx_wheel_codes_prize on wheel_codes(prize_id);

-- ------------------------------------------------------------
-- Trigger: updated_at automático en wheel_prizes
-- ------------------------------------------------------------
create or replace function fn_set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create trigger trg_wheel_prizes_updated_at
  before update on wheel_prizes
  for each row execute function fn_set_updated_at();

-- ------------------------------------------------------------
-- Función: generar código único formato TAFI-XXXXXX
-- (alfanumérico mayúsculas, sin caracteres ambiguos: sin 0/O, 1/I)
-- ------------------------------------------------------------
create or replace function fn_generate_wheel_code()
returns text as $$
declare
  chars text := 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'; -- sin 0,O,1,I,L
  result text := '';
  i integer;
  new_code text;
  exists_already boolean;
begin
  loop
    result := '';
    for i in 1..6 loop
      result := result || substr(chars, floor(random() * length(chars) + 1)::int, 1);
    end loop;
    new_code := 'TAFI-' || result;

    select exists(select 1 from wheel_codes where code = new_code) into exists_already;
    exit when not exists_already;
  end loop;

  return new_code;
end;
$$ language plpgsql;

-- ------------------------------------------------------------
-- Función principal: girar la ruleta
-- Elige premio por peso ponderado (solo entre los que tienen
-- quantity_remaining > 0 y active = true), descuenta stock,
-- genera y devuelve el código.
-- Todo en una transacción atómica (evita condiciones de carrera
-- si dos personas giran "al mismo tiempo").
-- ------------------------------------------------------------
create or replace function fn_spin_wheel()
returns table(out_code text, out_prize_id bigint, out_prize_name text, out_color text) as $$
declare
  total_weight numeric;
  current_weight numeric;
  random_pick numeric;
  running_total numeric := 0;
  selected_prize_id bigint;
  selected_prize_name text;
  selected_color text;
  generated_code text;
begin
  -- Bloquea las filas relevantes para evitar doble asignación concurrente
  perform 1 from wheel_prizes
    where active = true and quantity_remaining > 0
    for update;

  select coalesce(sum(weight), 0) into total_weight
  from wheel_prizes
  where active = true and quantity_remaining > 0 and weight > 0;

  if total_weight <= 0 then
    raise exception 'No hay premios disponibles con stock y peso configurado';
  end if;

  random_pick := random() * total_weight;

  -- Selección ponderada (acumulando en orden estable)
  running_total := 0;
  for selected_prize_id, selected_prize_name, selected_color in
    select p.id, p.name, p.color
    from wheel_prizes p
    where active = true and quantity_remaining > 0 and weight > 0
    order by p.sort_order, p.id
  loop
    select weight into strict current_weight from wheel_prizes where id = selected_prize_id;
    running_total := running_total + current_weight;
    if random_pick <= running_total then
      exit;
    end if;
  end loop;

  -- Descuenta stock
  update wheel_prizes
  set quantity_remaining = quantity_remaining - 1
  where id = selected_prize_id;

  -- Si se recalculan pesos automáticamente, ajusta los que no son manuales
  perform fn_recalculate_auto_weights();

  -- Genera código único
  generated_code := fn_generate_wheel_code();

  insert into wheel_codes (code, prize_id)
  values (generated_code, selected_prize_id);

  out_code := generated_code;
  out_prize_id := selected_prize_id;
  out_prize_name := selected_prize_name;
  out_color := selected_color;
  return next;
end;
$$ language plpgsql;

-- ------------------------------------------------------------
-- Función: recalcular pesos automáticos proporcional al stock
-- Solo toca los premios con weight_is_manual = false
-- ------------------------------------------------------------
create or replace function fn_recalculate_auto_weights()
returns void as $$
declare
  total_auto_remaining numeric;
begin
  select coalesce(sum(quantity_remaining), 0) into total_auto_remaining
  from wheel_prizes
  where weight_is_manual = false and active = true;

  if total_auto_remaining > 0 then
    update wheel_prizes
    set weight = round((quantity_remaining::numeric / total_auto_remaining) * 100, 3)
    where weight_is_manual = false and active = true;
  else
    update wheel_prizes
    set weight = 0
    where weight_is_manual = false and active = true;
  end if;
end;
$$ language plpgsql;

-- ------------------------------------------------------------
-- Función: canjear código
-- ------------------------------------------------------------
create or replace function fn_redeem_code(p_code text, p_redeemed_by text)
returns table(out_status text, out_prize_name text, out_message text) as $$
declare
  v_id bigint;
  v_status text;
  v_prize_name text;
begin
  select wc.id, wc.status, wp.name
  into v_id, v_status, v_prize_name
  from wheel_codes wc
  join wheel_prizes wp on wp.id = wc.prize_id
  where wc.code = upper(trim(p_code));

  if v_id is null then
    out_status := 'no_encontrado';
    out_prize_name := null;
    out_message := 'Código no existe';
    return next;
    return;
  end if;

  if v_status = 'canjeado' then
    out_status := 'ya_canjeado';
    out_prize_name := v_prize_name;
    out_message := 'Este código ya fue canjeado anteriormente';
    return next;
    return;
  end if;

  if v_status = 'expirado' then
    out_status := 'expirado';
    out_prize_name := v_prize_name;
    out_message := 'Este código expiró';
    return next;
    return;
  end if;

  update wheel_codes
  set status = 'canjeado', redeemed_at = now(), redeemed_by = p_redeemed_by
  where id = v_id;

  out_status := 'canjeado';
  out_prize_name := v_prize_name;
  out_message := 'Canje exitoso';
  return next;
end;
$$ language plpgsql;

-- ------------------------------------------------------------
-- Función: consultar el estado de UN código puntual (sin exponer
-- el resto de la tabla). Útil si el cliente quiere verificar su
-- propio código desde su celular antes de acercarse a canjear.
-- ------------------------------------------------------------
create or replace function fn_check_code(p_code text)
returns table(out_status text, out_prize_name text) as $$
begin
  return query
  select wc.status, wp.name
  from wheel_codes wc
  join wheel_prizes wp on wp.id = wc.prize_id
  where wc.code = upper(trim(p_code));
end;
$$ language plpgsql security definer;

grant execute on function fn_check_code(text) to anon, authenticated;

-- ------------------------------------------------------------
-- Row Level Security
-- La ruleta pública solo necesita: leer premios activos, girar,
-- y consultar su propio código. El canje requiere estar autenticado.
-- Para mantenerlo simple (uso único, un evento), usamos anon key
-- para la ruleta pública y auth de Supabase (email/password) para
-- la sección de canje y configuración.
-- ------------------------------------------------------------
alter table wheel_prizes enable row level security;
alter table wheel_codes enable row level security;

-- Cualquiera (anon) puede leer premios activos, para pintar la ruleta
create policy "wheel_prizes_public_read"
  on wheel_prizes for select
  to anon
  using (true);

-- NOTA: NO se da select público libre sobre wheel_codes — eso expondría
-- todos los códigos generados (de otros clientes) a cualquiera con la
-- anon key. La consulta de un código puntual se hace vía la función
-- fn_check_code() de abajo, que solo permite buscar por código exacto.

-- Solo usuarios autenticados (login de la encargada / tú) pueden
-- insertar/actualizar premios (sección Configuración)
create policy "wheel_prizes_auth_write"
  on wheel_prizes for all
  to authenticated
  using (true)
  with check (true);

-- Los inserts de wheel_codes solo pasan por fn_spin_wheel (security definer
-- no configurado aquí a propósito: se ejecuta con permisos del caller,
-- así que exponemos la función vía RPC y permitimos ejecutar a "anon")
create policy "wheel_codes_auth_write"
  on wheel_codes for update
  to authenticated
  using (true)
  with check (true);

-- Permitir a anon ejecutar la función de girar (inserta en wheel_codes
-- y actualiza wheel_prizes) — se marca como SECURITY DEFINER para que
-- corra con permisos de owner sin necesitar policies adicionales de insert
alter function fn_spin_wheel() security definer;
alter function fn_recalculate_auto_weights() security definer;
alter function fn_generate_wheel_code() security definer;

grant execute on function fn_spin_wheel() to anon, authenticated;
grant execute on function fn_redeem_code(text, text) to authenticated;
grant execute on function fn_recalculate_auto_weights() to authenticated;

-- ------------------------------------------------------------
-- Datos de ejemplo (puedes editarlos o borrarlos desde la app)
-- ------------------------------------------------------------
insert into wheel_prizes (name, color, quantity_total, quantity_remaining, weight, weight_is_manual, sort_order) values
  ('Empanada gratis', '#D97757', 50, 50, 0, false, 1),
  ('10% de descuento', '#4A7C6E', 100, 100, 0, false, 2),
  ('Bebida gratis', '#C9A34E', 30, 30, 0, false, 3),
  ('2x1 en empanadas', '#8E5B4F', 20, 20, 0, false, 4),
  ('Sigue participando', '#6B6560', 999, 999, 0, false, 5);

select fn_recalculate_auto_weights();
